<!DOCTYPE html>
<html>
<head>
<script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.1.1/crypto-js.min.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Add icon library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

.input-container {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  width: 100%;
  margin-bottom: 0px;
  margin-top:15px;

}

.input-container-add {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  width: 90%;
  margin-bottom: 0px;
  margin-top: 0px;
  margin-left: 50px;
}

.input-container-add2 {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  width: 100%;
  margin-top: 15px;
  margin-bottom: 15px;
  left: 50px;
}

.input-container-add3 {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  width: 100%;
  margin-top: 15px;
  margin-bottom: 0px;
}


.icon {
  padding: 10px;
  background: dodgerblue;
  color: white;
  min-width: 50px;
  text-align: center;
}

.input-field {
  width: 100%;
  padding: 10px;
  outline: none;
}

.input-field:focus {
  border: 2px solid dodgerblue;
}

/* Set a style for the submit button */
.btn {
  background-color: dodgerblue;
  color: white;
  padding: 15px 20px;
  border: none;
  cursor: pointer;
  width: 50;
  opacity: 0.9;
}

.btn:hover {
  opacity: 1;
}

body{
    background-image: url('assets/img/background.jpeg');
    background-repeat: repeat;
    background-attachment: fixed;
    background-size: 85%;
    background-blend-mode: luminosity;
}

@supports (-webkit-text-stroke: 2px rgb(249, 246, 246)) {
  h2 {
    -webkit-text-fill-color: rgb(244, 241, 241);
    -webkit-text-stroke: 1.2px rgb(5, 5, 5);
  }
}
</style>
</head>
<body>

<form onsubmit="return checkPassword()" action="Register_user.php" style="max-width:500px;margin:auto" method="post">

  <h2>USER REGISTRATION</h2>
  <div class="input-container">
    <i class="fa fa-user icon"></i>
    <input class="input-field" type="text" placeholder="Name" name="usrnm" required>
  </div>

  <div class="input-container-add3">
    <i class="fa fa-envelope icon"></i>
    <input class="input-field" type="text" placeholder="Email Address" name="email" required>
  </div>

  <div class="input-container">
    <i class="fa fa-address-book icon"></i>
    <input class="input-field" type="text" placeholder="Address 1" name="add" required> 
  </div>

  <div class="input-container-add">
    <input class="input-field" type="text" placeholder="Address 2" name="add1">
   
  </div>

  <div class="input-container-add">
    <input class="input-field" type="text" placeholder="Address 3" name="add2">
  </div>


  <div class="input-container-add2">
    <i class="fa fa-phone icon"></i>
    <input class="input-field" type="int" placeholder="Telephone number" name="phonenum" required>
  </div>

  <div class="input-container">
    <i class="fa fa-male icon"></i>
    <input class="input-field" type="text" placeholder="position" name="pos" required>
  </div>

  <div class="input-container">
    <i class="fa fa-group icon"></i>
    <input class="input-field" type="text" placeholder="Department" name="dept" required>
  </div>

  <div class="input-container">
    <i class="fa fa-lock icon"></i>
    <input class="input-field" type="password" Placeholder="Password" id="Password" name="psw" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
    <button type="button" onclick="togglePasswordVisibility('Password')">
      <i class="fa fa-eye" id="showPasswordIcon"></i>
    </button>
  </div>

  <div class="input-container">
    <i class="fa fa-lock icon"></i>
    <input class="input-field" type="password" Placeholder="Re-Type Password" id="Re-type Password" name="psw1" required>
  </div>

  <script src="https://www.google.com/recaptcha/api.js" async defer></script>
  <div class="g-recaptcha" data-sitekey="6LfUXbYoAAAAAOAkOlYftjsVtA8fdvaL7sr_UYj4"></div>

  <button type="submit" class="btn">Register</button>
</form>

<script>
function togglePasswordVisibility(inputId) {
  var passwordInput = document.getElementById(inputId);
  var showPasswordIcon = document.getElementById("showPasswordIcon");

  if (passwordInput.type === "password") {
    passwordInput.type = "text";
    showPasswordIcon.classList.remove("fa-eye");
    showPasswordIcon.classList.add("fa-eye-slash");
  } else {
    passwordInput.type = "password";
    showPasswordIcon.classList.remove("fa-eye-slash");
    showPasswordIcon.classList.add("fa-eye");
  }
}

var letter = document.getElementById("letter");
var capital = document.getElementById("capital");
var number = document.getElementById("number");
var length = document.getElementById("length");

// When the user clicks on the password field, show the message box
document.getElementById("Password").onfocus = function() {
  document.getElementById("message").style.display = "block";
}

// When the user clicks outside of the password field, hide the message box
document.getElementById("Password").onblur = function() {
  document.getElementById("message").style.display = "none";
}

// When the user starts to type something inside the password field
document.getElementById("Password").onkeyup = function() {
  // Validate lowercase letters
  var lowerCaseLetters = /[a-z]/g;
  if (document.getElementById("Password").value.match(lowerCaseLetters)) {
    letter.classList.remove("invalid");
    letter.classList.add("valid");
  } else {
    letter.classList.remove("valid");
    letter.classList.add("invalid");
  }

  // Validate capital letters
  var upperCaseLetters = /[A-Z]/g;
  if (document.getElementById("Password").value.match(upperCaseLetters)) {
    capital.classList.remove("invalid");
    capital.classList.add("valid");
  } else {
    capital.classList.remove("valid");
    capital.classList.add("invalid");
  }

  // Validate numbers
  var numbers = /[0-9]/g;
  if (document.getElementById("Password").value.match(numbers)) {
    number.classList.remove("invalid");
    number.classList.add("valid");
  } else {
    number.classList.remove("valid");
    number.classList.add("invalid");
  }

  // Validate length
  if (document.getElementById("Password").value.length >= 8) {
    length.classList.remove("invalid");
    length.classList.add("valid");
  } else {
    length.classList.remove("valid");
    length.classList.add("invalid");
  }
}

function checkPassword() {
  const password = document.getElementById("Password").value;
  const confirmPassword = document.getElementById("Re-type Password").value;

  if (password !== confirmPassword) {
    alert("Passwords do not match!");
    return false;
  } else {
    return true;
  }
}
</script>
</body>
</html>