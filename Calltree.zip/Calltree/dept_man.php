<!DOCTYPE html>
<html>
    <head>
<title>Manage User</title>
<meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard - SB Admin</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
  <style>

.heading {
    width: 100%;
    height: 10%;
    position: relative;
    
}
.rows {
    display: flex;
    margin-bottom: 15px;
}
.content {
    flex: 1;
    position:relative;
    top:15%;
}
.Attributes {
    flex: 1;
    margin-right: 10px;
}
.attributeform {
    background-color: #FFFCE9;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
    box-sizing: border-box; /* Ensure padding and border are included in the width calculation */
    height: 95%;
    position: static;
    margin-bottom: 30px;
}
.Attr {
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
    color: grey;
}
.Attr::first-letter {
    text-transform: capitalize;
}

#remark {
    width: 100%;
    height: 150px;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
    resize: vertical;
}
textarea {
    width: 100%;
    height: 100px;
    border: 1px solid #ccc;
    border-radius: 5px;
    padding: 5px;
    font-size: 14px;
}

.styling-options {
    margin-top: 10px;
}

button {
    font-weight: bold;
    border: none;
    cursor: pointer;
    margin-right: 5px;
}

.button {
    display: flex;
    justify-content: center;
    align-items: center;
}
#subbutton {
    background-color: #37517e;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 18px;
    margin-left: 10px;
}
#clbutton {
    background-color:lightgrey;
    color: black;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 18px;
    margin-left: 10px;
}

#subbutton:hover {
    background-color: #2980b9;
}
#clbutton:hover {
    background-color: #F0F8FF;
}
.topbutton {
    background-color: #37517e;
    display: flex;
    justify-content: flex-end ;
    align-items: center;
    position: static;
    right: 2%;
    padding: 10px;
}
#topbutton {
    background-color: white;
    color: black;
    border: none;
    padding: 5px 10px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 14px;
    margin-left: 5px;
}

#topbutton:hover {
    background-color: lightgrey;
}
.icon {
  width: 100px;
  height: 100px;
  border-radius: 50%;
  margin-bottom: 10px;
  object-fit: cover;
}


    </style>
    </head>
<body class="sb-nav-fixed"> 
<?php 
session_start();
require_once('inc/config.php');
?>
     <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="dashboard.php">Directory</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                <div class="input-group">
                    <input class="form-control" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                    <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button>
                </div>
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="my_profile.php">My Profile</a></li>
                        <li><hr class="dropdown-divider" /></li>
                        <li><a class="dropdown-item" href="index.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
                <div id="layoutSidenav_nav">
                    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                        <?php include 'sidenav.php'; ?>
                    </nav>
                </div>
                    <div id="layoutSidenav_content">
                            <main>
                                <div class="container-fluid px-4">
                                    <br>
                                    <h4>Department Mangement</h4>
                                    <hr>
                                    <div class= topbutton>
                                        <p style="color:white; margin-right:51%; margin-bottom:0; font-size: 18px;">Department</p>
                                        <button type="button" id="topbutton" onclick="info()">Info</button>
                                        <button type="button" id="topbutton" onclick="add()">Add</button>
                                        <button type="button" id="topbutton" onclick="massEdit()">Mass Edit</button>
                                        <button type="button" id="topbutton" onclick="importCSV()">Import CSV</button>
                                        <button type="button" id="topbutton" onclick="exportCSV()">Export List as CSV</button>
                                    </div>
                                    <form method="POST" action="Process_form.php" class = "attributeform">
                                        <p><strong>Add Department</strong></p>  
                                        <hr>    
                                            <div class="content">
                                                <div class="rows">
                                                    <div class="Attributes">
                                                        <div>Department Name</div>
                                                        <div><input type="text" name="loc_name" class="Attr" value=""></div>
                                                    </div>
                                                    <div class="Attributes">
                                                        <div>Department ID</div>
                                                        <div>
                                                                <select id="loc_stat" name="loc_stat" class="Attr" required>
                                                                    <option>Select Location Status</option>
                                                                    <option value=""></option>
                                                                </select>
                                                            </div>
                                                    </div>
                                                    <div class="Attributes">
                                                        <div>Employee Assigned</div>
                                                        <div>
                                                                <select id="loc_type" name="loc_type" class="Attr" required>
                                                                    <option>Select Employee Assigned</option>
                                                                    <option value=""></option>
                                                                </select>
                                                            </div>
                                                    </div>
                                                    <div class="Attributes">
                                                        <div>Alternate Employee</div>
                                                        <div>
                                                                <select id="man" name="man" class="Attr" required>
                                                                    <option>Select Alternate Employee</option>
                                                                    <option value=""></option>
                                                                </select>
                                                            </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                <textarea id="styled-textarea"></textarea>
                                                    <div class="styling-options">
                                                        <button id="bold-button">B</button>
                                                        <button id="italic-button">I</button>
                                                        <button id="underline-button">U</button>
                                                    </div>
                                                <script>
                                                    const textarea = document.getElementById('styled-textarea');
                                                    const boldButton = document.getElementById('bold-button');
                                                    const italicButton = document.getElementById('italic-button');
                                                    const underlineButton = document.getElementById('underline-button');

                                                    boldButton.addEventListener('click', () => {
                                                        applyStyle('bold');
                                                    });

                                                    italicButton.addEventListener('click', () => {
                                                        applyStyle('italic');
                                                    });

                                                    underlineButton.addEventListener('click', () => {
                                                        applyStyle('underline');
                                                    });

                                                    function applyStyle(style) {
                                                        const selectedText = textarea.value.substring(textarea.selectionStart, textarea.selectionEnd);
                                                        const textBeforeSelection = textarea.value.substring(0, textarea.selectionStart);
                                                        const textAfterSelection = textarea.value.substring(textarea.selectionEnd);

                                                        const styledText = `<${style}>${selectedText}</${style}>`;

                                                        textarea.value = textBeforeSelection + styledText + textAfterSelection;
                                                    }
                                                </script>


                                            </div>
                                            <br>
                                            <input type="hidden" name="user_id" value="<?php echo isset($_GET['id']) ? $_GET['id'] : ''; ?>">
                                            <div class= "button"><button type="submit" name="submitb" id="subbutton" >Update</button>
                                                <button type="clear" name="clearb" id="clbutton" >Clear</button>
                                                <button type="cancel" name="cancelb" id="clbutton" >Cancel</button>
                                            </div>
                                        
                                    </form>
                                </div>
                            </main>
                            <footer class="py-4 bg-light mt-auto">
                            <div class="container-fluid px-4">
                                <div class="d-flex align-items-center justify-content-between small">
                                    <div class="text-muted">Copyright &copy; Your Website 2023</div>
                                    <div>
                                        <a href="#">Privacy Policy</a>
                                        &middot;
                                        <a href="#">Terms &amp; Conditions</a>
                                    </div>
                                </div>
                            </div>
                        </footer>
                    </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
</body>
</html>

