<!DOCTYPE html>
<html>
    <head>
<title>Manage User</title>
<meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard - SB Admin</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
  <style>

.heading {
    width: 100%;
    height: 10%;
    position: relative;
    
}
.rows {
    display: flex;
    margin-bottom: 15px;
}
.content {
    flex: 1;
    position:relative;
    top:15%;
    left:%;
}
.Attributes {
    flex: 1;
    margin-right: 10px;
}
.attributeform {
    background-color: #FFFCE9;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
    width: 80%; /* Set the form width to 100% */
    box-sizing: border-box; /* Ensure padding and border are included in the width calculation */
    height: 95%;
    position: static;
    margin-left:18%;
    margin-bottom: 30px;
}
.Attr {
    width: 90%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
    text-transform: uppercase;
    color: grey;
}

#remark {
    width: 100%;
    height: 150px;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
    resize: vertical;
}
.button {
    display: flex;
    justify-content: flex-end;
    align-items: center;
}
#subbutton {
    background-color: #37517e;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 18px;
    margin-left: 10px;
}

#subbutton:hover {
    background-color: #2980b9;
}
.icon {
  width: 100px;
  height: 100px;
  border-radius: 50%;
  margin-bottom: 10px;
  object-fit: cover;
}
h4 {
    margin-left: 17%;
    margin-top: 2%;
}
    </style>
    </head>
<body class="sb-nav-fixed"> 
<?php 
session_start();
require_once('inc/config.php');
?>
     <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="dashboard.php">Directory</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                <div class="input-group">
                    <input class="form-control" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                    <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button>
                </div>
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="my_profile.php">My Profile</a></li>
                        <li><hr class="dropdown-divider" /></li>
                        <li><a class="dropdown-item" href="index.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <?php include 'sidenav.php'; ?>
                </nav>
            </div>
        </div>
        <?php
          // Check if the user ID is passed in the URL
          // Assuming you have a user ID available, you can store it in the session like this:
        $_SESSION['id'];

          if (isset($_SESSION['id'])) {
            $userId = $_SESSION['id'];
            // Now you have access to the user ID, and you can use it as needed in your "UserProfile.php" file.
            // For example, you can use it to display user-specific data or perform actions related to the user.
        }
        else{
            echo "Connection failed";
        }

        include 'Process_form.php'; 
        //$currentPage = basename($_SERVER['PHP_SELF']);
        //$userId = isset($_GET['id']);
        if(isset($_SESSION['id'])){
            $usertable = new usertable();
            $userData = $usertable->fetchData($_SESSION['id']);  //adjut this to show the user_id =1
        }
        ?>
                            <div id="layoutSidenav_content">
                                <main>
                            <div class="container-fluid px-4">
                                <br>
                                <br>
                                    <h4>Manage Profile</h4>
                                    <br>
                                    <form method="POST" action="Process_form.php" class = "attributeform">
                                        <div class = "rows">        
                                            <br>
                                            <div class="content">
                                                <div class="rows">
                                                    <div class="Attributes">
                                                        <div>ID</div>
                                                        <div><input type="text" name="id" class="Attr" value="<?php echo $userData["id"]?>"></div>
                                                    </div>
                                                    <div class="Attributes">
                                                        <div>Name</div>
                                                        <div><input type="text" name="name" class="Attr" value="<?php echo $userData["name"]?>"></div>
                                                    </div>
                                                </div>
                                                <div class="rows">
                                                    <div class="Attributes">
                                                        <div>Address</div>
                                                        <div><input type="text" name="addr" class="Attr" value="<?php echo $userData["address"]?>"></div>
                                                    </div>
                                                    <div class="Attributes">
                                                        <div>Address Line 2</div>
                                                        <div><input type="text" name="addr2" class="Attr" value="<?php echo $userData["address2"]?>"></div>
                                                    </div>
                                                </div>
                                                <div class="rows">
                                                <div class="Attributes">
                                                        <div>Address Line 3</div>
                                                        <div><input type="text" name="addr3" class="Attr" value="<?php echo $userData["address3"]?>"></div>
                                                    </div>
                                                    <div class="Attributes">
                                                            <div>Age</div>
                                                            <div><input type="text" name="age" class="Attr" value="<?php echo $userData["age"]?>"></div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="Attributes">
                                                            <div>Phone Number</div>
                                                            <div><input type="text" name="num" class="Attr" value="<?php echo $userData["telephone_number"]?>"></div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="Attributes">
                                                            <div>Position</div>
                                                            <div><input type="text" name="pos" class="Attr" value="<?php echo $userData["position"]?>"></div>
                                                    </div>
                                                </div>

                                            <div class="rows">
                                                    <div class="Attributes">
                                                        <div>Department</div>
                                                        <div><select id="department" name="department" class="Attr" required>
                                                        <option><?php echo $userData["Department"]?></option>
                                                        <option value="IT">IT</option>
                                                        </select>
                                                        </div>
                                                    </div>
                                            </div>
                                                
                                            <div class="rows">
                                                <div class="Attributes">
                                                    <div >Remarks</div>
                                                    <div ><textarea type="textarea" name="remark" id="remark" class="Attr"><?php echo $userData["remark"]?></textarea></div>
                                                </div>
                                            </div>
                                            
                                            <input type="hidden" name="user_id" value="<?php echo isset($_GET['id']) ? $_GET['id'] : ''; ?>">
                                            <div class= "button"><button type="submit" name="submitb" id="subbutton" >Update</button></div>
                                        
                             </form>
                         </div>
                     </main>
                
    </div>

    </body>

</html>

