<?php

session_start();
// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $databaseName = "manage_user";
    
    //connect database
    $conn = new mysqli($servername,$username,$password,$databaseName);
    if($conn->connect_error){
        die("Fail to Connect:". $conn->connect_error);
    }
    

   
    function generateMeaningfulID() {
        $prefix = 'UID';
    
        // Check if the last ID is stored in session, if not, start from 1
        if (!isset($_SESSION['last_id'])) {
            $_SESSION['last_id'] = 1;
        }
    
        // Get the current ID
        $currentID = $_SESSION['last_id'];
    
        // Increment the ID
        $currentID++;
    
        // If the ID reaches 1001, reset it back to 1
        if ($currentID > 1000) {
            $currentID = 1;
        }
    
        // Update the last ID in the session
        $_SESSION['last_id'] = $currentID;
    
        // Generate the meaningful ID
        $meaningfulID = $prefix . '-' . date('Ymd') . '-' . str_pad($currentID, 3, '0', STR_PAD_LEFT);
    
        return $meaningfulID;
    }
    
    $userID = generateMeaningfulID();
    
    
    // Set the timezone to Malaysia (MYT)
    //date_default_timezone_set('Asia/Kuala_Lumpur');
    // Get the current date
    // Get the current time
    
    $timestamp = date('Y-m-d H:i:s', strtotime('+6 hours'));
    // Retrieve form data
    
    $username = mysqli_real_escape_string($conn, $_POST['usrnm']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $address = mysqli_real_escape_string($conn, $_POST['add']);
    $address2 = mysqli_real_escape_string($conn, $_POST['add1']);
    $address3 = mysqli_real_escape_string($conn, $_POST['add2']);
    $phonenumber = mysqli_real_escape_string($conn, $_POST['phonenum']);
    $position = mysqli_real_escape_string($conn, $_POST['pos']);
    $department = mysqli_real_escape_string($conn, $_POST['dept']);
    $password = mysqli_real_escape_string($conn, $_POST['psw']);
    $md5password = md5($password);
    $datetimeValue = mysqli_real_escape_string($conn, $timestamp);
   

    

    //insert
    $insertQuery = "INSERT INTO manage_user (id, email, name, age, address, address2, telephone_number, position, department, password) 
    VALUES ('$userID','$email','$username',32, '$address','$address2','$phonenumber','$position','$department','$md5password')";

    if ($conn->query($insertQuery) === TRUE) {
        echo "Registration successfull";
    } else {
        echo "Some Error Happened!".$conn->error;
    }
    // Handle file uploads
    // ... (the file upload code, as discussed earlier)

    // Save the complaint data in a database or file (you need to implement this part)
    // For this example, let's assume we save the data in a text file named "complaints.txt"
   
    $data = "User ID: " . $userID . "\n";
    $data .= "Email: " . $email . "\n";
    $data .= "Name: $username\n";
    $data .= "Address Line 1: $address\n";
    $data .= "Address Line 2: $address2\n";
    $data .= "Address Line 3: $address3\n";
    $data .= "Telephone Number: $phonenumber\n";
    $data .= "Position: $position\n";
    $data .= "Department: $department\n";

    $file = fopen('user.txt', 'a');
    fwrite($file, $data);
    fclose($file);
    
    
} else {
    /// If the form is accessed directly without submission, show an error message
    echo "<h2>Error: Access Denied</h2>";
    echo "<p>Sorry, you can't access this page directly.
    Please go back to the registration form and submit your information.</p>";
}
?>
