<?php

class usertable {
    public $id;
    public $email;
    public $name;
    public $age;
    public $address;
    public $address2;
    public $address3;
    public $telephone_num;
    public $position;
    public $department;
    public $dept;

    public function fetchData($id) {
        
        // Database parameters
        $servername = "localhost";
        $username = "root";
        $password = "";
        $databaseName = "manage_user";

        // Connect to the database
        $conn = new mysqli($servername, $username, $password, $databaseName);
        if ($conn->connect_error) {
            die("Failure to connect: " . $conn->connect_error);
        }

        $sql = "SELECT * FROM manage_user WHERE id = '$id'";
        $result = $conn->query($sql);
        
        if ($result) {
            $row = $result->fetch_assoc();
            $id = $row["id"];
            $email = $row["email"];
            $name = $row["name"];
            $age = $row["age"];
            $address = $row["address"];
            $address2 = $row["address2"];
            $address3 = $row["address3"];
            $telephone_num = $row["telephone_number"];
            $position = $row["position"];
            $department = $row["department"];
           
            $sql2 = "SELECT Department FROM department WHERE id_dept = '$department'";
            $result2 = $conn->query($sql2);
                if ($result2) {
                    $row2 = $result2->fetch_assoc();
                    $dept = $row2["Department"];
                }
                
            // If there's a "remark" field in your database, you can add it here.
            // $this->remark = $row["remark"];
        }
        
        return [
            "id" => $id,
            "email" => $email,
            "name" => $name,
            "age" => $age,
            "address" => $address,
            "address2" => $address2,
            "address3" => $address3,
            "telephone_number" => $telephone_num,
            "position" => $position,
            "Department" => $dept
        ];

       
    }
}
?>






