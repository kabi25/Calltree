<?php 
	 $servername = "localhost";
	 $username = "root";
	 $password = "";
	 $databaseName = "manage_user";
 
	 $conn = new mysqli($servername, $username, $password, $databaseName);
	
	if(!$conn)
	{
		die(mysqli_error());
	}
	
	
	
	function getUserAccessRoleByID($id)
	{
		global $conn;
		
		$query = "select user_role from tbl_user_role where  id = ".$id;
	
		$rs = mysqli_query($conn,$query);
		$row = mysqli_fetch_assoc($rs);
		
		return $row['user_role'];
	}
?>