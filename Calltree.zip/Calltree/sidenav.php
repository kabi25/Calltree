<div class="sb-sidenav-menu">
        <div class="nav">

                        <?php
                        //only visible to admin and editor
                        if($_SESSION['role'] == 1 || $_SESSION['role'] == 2){?>
                            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseMain" aria-expanded="false" aria-controls="collapseMain">
                                <div class="sb-sidenav-menu-heading" style="font-size: 16px" >Main</div>
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" id="collapseMain" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordionMain">
                                <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionMain">
                                    <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseMB" aria-expanded="false" aria-controls="collapseMB">
                                        Manage Broadcast
                                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                    </a>
                                    <div class="collapse" id="collapseMB" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordionMB">
                                        <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionMB">
                                                <a class="nav-link" href="#">Message Template</a>
                                                <a class="nav-link" href="#">Broadcast Template</a>
                                                <a class="nav-link" href="#">Broadcast Set Up</a>
                                        </nav>
                                    </div>  
                                    <a class="nav-link" href="#">
                                        Activation List
                                    </a>
                                    <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseAM" aria-expanded="false" aria-controls="collapseAM">
                                        Activation Monitoring
                                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                    </a>
                                    <div class="collapse" id="collapseAM" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordionAM">
                                        <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionAM">
                                                <a class="nav-link" href="dashboard.php">Dashboard</a>
                                                <a class="nav-link" href="#">Response</a>
                                        </nav>
                                    </div>
                                    <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseAC" aria-expanded="false" aria-controls="collapseAC">
                                        Activation Complete
                                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                    </a>
                                    <div class="collapse" id="collapseAC" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordionAC">
                                        <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionAC">
                                                <a class="nav-link" href="#">Report</a>
                                        </nav>
                                    </div>
                                </nav>
                            </div>
                        <?php }?>

                        <?php
                        //only visible to admin
                        if(($_SESSION['role'] == 1)){?>
                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseMore" aria-expanded="false" aria-controls="collapseMore">
                                <div class="sb-sidenav-menu-heading" style="font-size: 16px" >More</div>
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" id="collapseMore" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordionMore">
                                <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionConnect">
                                    <a class="nav-link" href="location_man.php">
                                        Location Management
                                    </a>
                                    <a class="nav-link" href="user_profile.php">
                                        Employee Management
                                    </a>
                                    <a class="nav-link" href="#">
                                        Team Management
                                    </a>
                                    <a class="nav-link" href="dept_man.php">
                                        Department Management
                                    </a>
                                    <a class="nav-link" href="#">
                                        Audit Trail
                                    </a> 
                                    <a class="nav-link" href="#">
                                        Alert Setting
                                    </a>    
                                </nav>
                            </div>
                            
                        <?php } ?>

        </div>
</div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Logged in as:</div>
                        <?php echo getUserAccessRoleByID($_SESSION['role']); ?>
                    </div>